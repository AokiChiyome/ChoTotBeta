package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class donmua extends AppCompatActivity {
    TextView Btn_dangxuly , Btn_danggiao , Btn_dagiao;
    ImageButton Btn_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donmua_choxacnhan);
        Btn_dangxuly = (TextView) findViewById(R.id.tvdangxulydonmua1);
        Btn_danggiao = (TextView)findViewById(R.id.tvdanggiaodonmua1);
        Btn_dagiao = (TextView)findViewById(R.id.tvdagiaodonmua1);
        Btn_back = (ImageButton)findViewById(R.id.Btn_donmuaxacnhantohome);
        Btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(donmua.this, taikhoan.class);
                startActivity(back);
            }
        });
        Btn_danggiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent danggiao = new Intent(donmua.this, donmua_danggiao.class);
                startActivity(danggiao);
            }
        });
        Btn_dagiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dagiao = new Intent(donmua.this, donmua_dagiao.class);
                startActivity(dagiao);
            }
        });
        Btn_dangxuly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dangxuly = new Intent(donmua.this, donmua_dangxuly.class);
                startActivity(dangxuly);
            }
        });
    }
}
