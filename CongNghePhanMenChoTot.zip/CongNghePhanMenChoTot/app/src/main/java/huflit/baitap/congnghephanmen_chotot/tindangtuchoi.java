package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class tindangtuchoi extends AppCompatActivity {
    TextView Btn_TaiKhoan  , Btn_Dangtin , Btn_Timkiem , Btn_TrangChu , Btn_DangHienThi,Btn_CanThanhToan,Btn_Hethan,Btn_lkv;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qldtbituchoi);
        Btn_TaiKhoan =(TextView)findViewById(R.id.Btn_TaiKhoan);
        Btn_Dangtin = (TextView) findViewById(R.id.Btn_Dangtin);
        Btn_TrangChu = (TextView)findViewById(R.id.Btn_TrangChu);
        Btn_Timkiem = (TextView) findViewById(R.id.Btn_TimKiem);
        Btn_DangHienThi = (TextView) findViewById(R.id.Btn_DangHienThi);
        Btn_CanThanhToan = (TextView) findViewById(R.id.Btn_CanThanhToan);
        Btn_Hethan = (TextView) findViewById(R.id.Btn_HetHan);
        Btn_lkv = (TextView)findViewById(R.id.Btn_lkv);
        Btn_lkv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  lkv = new Intent(tindangtuchoi.this, lienketvi.class);
                startActivity(lkv);
            }
        });
        Btn_DangHienThi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Hethan = new Intent(tindangtuchoi.this, quanlytindang.class);
                startActivity(Hethan);
            }
        });
        Btn_CanThanhToan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Canthanhtoan = new Intent(tindangtuchoi.this, canthanhtoan.class);
                startActivity(Canthanhtoan);
            }
        });
        Btn_Hethan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Canthanhtoan = new Intent(tindangtuchoi.this, tindanghethan.class);
                startActivity(Canthanhtoan);
            }
        });
        Btn_Dangtin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Dangtin = new Intent(tindangtuchoi.this, dangtin.class);
                startActivity(Dangtin);
            }
        });
        Btn_TrangChu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Trangchu = new Intent(tindangtuchoi.this, trangchu.class);
                startActivity(Trangchu);
            }
        });
        Btn_Timkiem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TimKiem = new Intent(tindangtuchoi.this, timkiem.class);
                startActivity(TimKiem);
            }
        });
        Btn_TaiKhoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TaiKhoan = new Intent(tindangtuchoi.this, taikhoan.class);
                startActivity(TaiKhoan);
            }
        });
    }
}
