package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class tindanghethan extends AppCompatActivity {
    TextView Btn_TaiKhoan  , Btn_Dangtin , Btn_Timkiem , Btn_TrangChu , Btn_DangHienThi,Btn_TuChoi,Btn_CanThanhToan,Btn_lkv;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qldthethan);
        Btn_TaiKhoan =(TextView)findViewById(R.id.Btn_TaiKhoan);
        Btn_Dangtin = (TextView) findViewById(R.id.Btn_Dangtin);
        Btn_TrangChu = (TextView)findViewById(R.id.Btn_TrangChu);
        Btn_Timkiem = (TextView) findViewById(R.id.Btn_TimKiem);
        Btn_DangHienThi = (TextView) findViewById(R.id.Btn_DangHienThi);
        Btn_TuChoi = (TextView) findViewById(R.id.Btn_TuChoi);
        Btn_CanThanhToan = (TextView) findViewById(R.id.Btn_CanThanhToan);
        Btn_lkv = (TextView)findViewById(R.id.Btn_lkv);
        Btn_lkv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  lkv = new Intent(tindanghethan.this, lienketvi.class);
                startActivity(lkv);
            }
        });
        Btn_DangHienThi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent DangHienThi= new Intent(tindanghethan.this, quanlytindang.class);
                startActivity(DangHienThi);
            }
        });
        Btn_TuChoi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TuChoi = new Intent(tindanghethan.this, tindangtuchoi.class);
                startActivity(TuChoi);
            }
        });
        Btn_CanThanhToan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Canthanhtoan = new Intent(tindanghethan.this, canthanhtoan.class);
                startActivity(Canthanhtoan);
            }
        });
        Btn_Dangtin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Dangtin = new Intent(tindanghethan.this, dangtin.class);
                startActivity(Dangtin);
            }
        });
        Btn_TrangChu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Trangchu = new Intent(tindanghethan.this, trangchu.class);
                startActivity(Trangchu);
            }
        });
        Btn_Timkiem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TimKiem = new Intent(tindanghethan.this, timkiem.class);
                startActivity(TimKiem);
            }
        });
        Btn_TaiKhoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TaiKhoan = new Intent(tindanghethan.this, taikhoan.class);
                startActivity(TaiKhoan);
            }
        });
    }
}
