package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
public class dangki extends AppCompatActivity {
    TextView Btn_toDangNhap ;
    ImageButton Btn_backtohome;
    EditText edtHovaten,edtPassword,edtsdt;
    Button Btn_dangky;
    private  FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        Btn_toDangNhap = (TextView)findViewById(R.id.tvdangnhap);
        Btn_backtohome = (ImageButton) findViewById(R.id.Btn_dangkitohome) ;
        Btn_dangky = findViewById(R.id.btn_dangki);
        edtHovaten = findViewById(R.id.HovaTen);
        edtPassword = findViewById(R.id.MatKhau);
        edtsdt = findViewById(R.id.SoDienThoai);

        Btn_backtohome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  backtohome = new Intent(dangki.this, taikhoan.class);
                startActivity(backtohome);
            }
        });
        Btn_toDangNhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent todangnhap = new Intent(dangki.this, dangnhap.class);
                startActivity(todangnhap);
            }
        });
        Btn_dangky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickSignUp();

            }
        });
    }
 private void onClickSignUp() {
        String strHoVaten = edtHovaten.getText().toString().trim();
        String strpass = edtPassword.getText().toString().trim();
        String strsdt = edtsdt.getText().toString().trim();
        if(TextUtils.isEmpty(strHoVaten)){
            Toast.makeText(this,"Vui lòng nhập Họ và tên",Toast.LENGTH_SHORT).show();
            return;
        }

        if(TextUtils.isEmpty(strpass)){
            Toast.makeText(this,"Vui lòng nhập mật khẩu",Toast.LENGTH_SHORT).show();
            return;
        }

        if(TextUtils.isEmpty(strsdt)){
            Toast.makeText(this,"Vui lòng nhập số điện thoại",Toast.LENGTH_SHORT).show();
            return;
        }
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.createUserWithEmailAndPassword(strHoVaten, strpass )
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(dangki.this, "Tạo tài khoản thành công.",Toast.LENGTH_SHORT).show();
                            // Sign in success, update UI with the signed-in user's information
                            Intent intent = new Intent(dangki.this,trangchu.class);
                            startActivity(intent);
                            finishAffinity();
                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(dangki.this, "Tạo tài khoản thất bại.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
