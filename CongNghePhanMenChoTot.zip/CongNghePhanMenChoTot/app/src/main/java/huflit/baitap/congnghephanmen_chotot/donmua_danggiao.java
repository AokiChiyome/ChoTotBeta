package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class donmua_danggiao extends AppCompatActivity {
    TextView Btn_dangxuly , Btn_dagiao , Btn_choxacnhan ;
    ImageButton Btn_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donmua_danggiao);
        Btn_dangxuly = (TextView) findViewById(R.id.tvdangxulydonmua3);
        Btn_dagiao = (TextView)findViewById(R.id.tvdagiaodonmua3);
        Btn_choxacnhan = (TextView)findViewById(R.id.tvchoxacnhandonmua3);
        Btn_back = (ImageButton)findViewById(R.id.Btn_donmuadanggiaotohome);
        Btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(donmua_danggiao.this, taikhoan.class);
                startActivity(back);
            }
        });
        Btn_dagiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent danggiao = new Intent(donmua_danggiao.this, donmua_dagiao.class);
                startActivity(danggiao);
            }
        });
        Btn_choxacnhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dagiao = new Intent(donmua_danggiao.this, donmua.class);
                startActivity(dagiao);
            }
        });
        Btn_dangxuly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dangxuly = new Intent(donmua_danggiao.this, donmua_dangxuly.class);
                startActivity(dangxuly);
            }
        });
    }
}
