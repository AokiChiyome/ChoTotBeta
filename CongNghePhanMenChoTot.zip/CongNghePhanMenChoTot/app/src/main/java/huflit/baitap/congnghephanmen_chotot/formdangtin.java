package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class formdangtin extends AppCompatActivity {

    ImageButton Btn_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dangtin);
        Btn_back = (ImageButton) findViewById(R.id.Btn_formtohome);
        Btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dangtindanhmuc = new Intent(formdangtin.this, dangtin.class);
                startActivity(Dangtindanhmuc);
            }
        });
    }
}
