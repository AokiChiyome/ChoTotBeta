package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class trangchu extends AppCompatActivity {
    TextView Btn_Quanlytindang  , Btn_Dangtin , Btn_TaiKhoan , Btn_Timkiem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trangchu);
        Btn_Quanlytindang =(TextView) findViewById(R.id.Btn_Quanlytindang);
        Btn_TaiKhoan =(TextView)findViewById(R.id.Btn_TaiKhoan);
        Btn_Dangtin = (TextView) findViewById(R.id.Btn_Dangtin);
        Btn_Timkiem = (TextView) findViewById(R.id.Btn_TimKiem);
        Btn_Quanlytindang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent quanlytindang = new Intent(trangchu.this, quanlytindang.class);
                startActivity(quanlytindang);
            }
        });
        Btn_Dangtin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Dangtin = new Intent(trangchu.this, dangtin.class);
                startActivity(Dangtin);
            }
        });
        Btn_TaiKhoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TaiKhoan = new Intent(trangchu.this, taikhoan.class);
                startActivity(TaiKhoan);
            }
        });
        Btn_Timkiem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TimKiem = new Intent(trangchu.this, timkiem.class);
                startActivity(TimKiem);
            }
        });

    }

}