package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class quanlytindang extends AppCompatActivity {
    TextView Btn_TaiKhoan  , Btn_Dangtin , Btn_Timkiem , Btn_TrangChu , Btn_HetHan,Btn_TuChoi,Btn_CanThanhToan,Btn_lkv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qldtdanghienthi);
        Btn_TaiKhoan =(TextView)findViewById(R.id.Btn_TaiKhoan);
        Btn_Dangtin = (TextView) findViewById(R.id.Btn_Dangtin);
        Btn_TrangChu = (TextView)findViewById(R.id.Btn_TrangChu);
        Btn_Timkiem = (TextView) findViewById(R.id.Btn_TimKiem);
        Btn_HetHan = (TextView) findViewById(R.id.Btn_HetHan);
        Btn_TuChoi = (TextView) findViewById(R.id.Btn_TuChoi);
        Btn_CanThanhToan = (TextView) findViewById(R.id.Btn_CanThanhToan);
        Btn_lkv = (TextView)findViewById(R.id.Btn_lkv);
        Btn_lkv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  lkv = new Intent(quanlytindang.this, lienketvi.class);
                startActivity(lkv);
            }
        });
        Btn_HetHan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Hethan = new Intent(quanlytindang.this, tindanghethan.class);
                startActivity(Hethan);
            }
        });
        Btn_TuChoi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TuChoi = new Intent(quanlytindang.this, tindangtuchoi.class);
                startActivity(TuChoi);
            }
        });
        Btn_CanThanhToan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Canthanhtoan = new Intent(quanlytindang.this, canthanhtoan.class);
                startActivity(Canthanhtoan);
            }
        });
        Btn_Dangtin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Dangtin = new Intent(quanlytindang.this, dangtin.class);
                startActivity(Dangtin);
            }
        });
        Btn_TrangChu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Trangchu = new Intent(quanlytindang.this, trangchu.class);
                startActivity(Trangchu);
            }
        });
        Btn_Timkiem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent  TimKiem = new Intent(quanlytindang.this, timkiem.class);
                startActivity(TimKiem);
            }
        });
        Btn_TaiKhoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TaiKhoan = new Intent(quanlytindang.this, taikhoan.class);
                startActivity(TaiKhoan);
            }
        });
    }

}
