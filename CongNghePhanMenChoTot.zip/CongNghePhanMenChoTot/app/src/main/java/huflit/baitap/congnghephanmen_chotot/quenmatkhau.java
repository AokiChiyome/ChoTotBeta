package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class quenmatkhau extends AppCompatActivity {
    Button Btn_xacnhan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quenmk);
        Btn_xacnhan = (Button) findViewById(R.id.Btn_xacnhan);
        Btn_xacnhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent quyvetrangchu = new Intent(quenmatkhau.this, otp.class);
                startActivity(quyvetrangchu);
            }
        });
    }
}
