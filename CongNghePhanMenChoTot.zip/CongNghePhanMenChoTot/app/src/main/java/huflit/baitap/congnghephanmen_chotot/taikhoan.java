package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class taikhoan extends AppCompatActivity {
    TextView Btn_Quanlytindang  , Btn_Dangtin , Btn_Timkiem , Btn_TrangChu , Btn_Dangnhap , Btn_Dangki,Btn_Donmua,Btn_Donba , Btn_chat , Btn_Dichvutienich , Btn_Danhgia , Btn_Donggopykien ,Btn_Caidattaikhoan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.taikhoan);
        Btn_Quanlytindang =(TextView) findViewById(R.id.Btn_Quanlytindang);
        Btn_Dangtin = (TextView) findViewById(R.id.Btn_Dangtin);
        Btn_chat = (TextView) findViewById(R.id.Btn_chat);
        Btn_TrangChu = (TextView)findViewById(R.id.Btn_TrangChu);
        Btn_Timkiem = (TextView) findViewById(R.id.Btn_TimKiem);
        Btn_Dangki = (TextView) findViewById(R.id.Btn_Dangki);
        Btn_Dangnhap = (TextView)findViewById(R.id.Btn_Dangnhap);
        Btn_Donmua = (TextView)findViewById(R.id.Btn_Donmua);
        Btn_Donba = (TextView) findViewById(R.id.Btn_Donban);
        Btn_Danhgia = (TextView) findViewById(R.id.Btn_danhgia);
        Btn_Donggopykien = (TextView)findViewById(R.id.Btn_donggopykien);
        Btn_Caidattaikhoan = (TextView)findViewById(R.id.Btn_caidattaikhoan);
        Btn_Dichvutienich =(TextView) findViewById(R.id.Btn_dichvutienich);
        Btn_Caidattaikhoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent caidattaikhoan = new Intent(taikhoan.this, caidatthongtin.class);
                startActivity(caidattaikhoan);
            }
        });
        Btn_Donggopykien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent donggiopykien = new Intent(taikhoan.this, donggopykien.class);
                startActivity(donggiopykien);
            }
        });
        Btn_Danhgia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent danhgia = new Intent(taikhoan.this, danhgia.class);
                startActivity(danhgia);
            }
        });
        Btn_Dichvutienich.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dichvutienich = new Intent(taikhoan.this, dichvutienich.class);
                startActivity(dichvutienich);
            }
        });
        Btn_chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent chat = new Intent(taikhoan.this, chat.class);
                startActivity(chat);
            }
        });
        Btn_Dangki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dangki = new Intent(taikhoan.this, dangki.class);
                startActivity(Dangki);
            }
        });
        Btn_Dangnhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dangnhap = new Intent(taikhoan.this, dangnhap.class);
                startActivity(Dangnhap);
            }
        });
        Btn_Donmua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Donmua = new Intent(taikhoan.this, donmua.class);
                startActivity(Donmua);
            }
        });
        Btn_Donba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Donban = new Intent(taikhoan.this, donban.class);
                startActivity(Donban);
            }
        });
        Btn_Quanlytindang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent quanlytindang = new Intent(taikhoan.this, quanlytindang.class);
                startActivity(quanlytindang);
            }
        });
        Btn_Dangtin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Dangtin = new Intent(taikhoan.this, dangtin.class);
                startActivity(Dangtin);
            }
        });
        Btn_TrangChu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  Trangchu = new Intent(taikhoan.this, trangchu.class);
                startActivity(Trangchu);
            }
        });
        Btn_Timkiem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  TimKiem = new Intent(taikhoan.this, timkiem.class);
                startActivity(TimKiem);
            }
        });
    }
}
