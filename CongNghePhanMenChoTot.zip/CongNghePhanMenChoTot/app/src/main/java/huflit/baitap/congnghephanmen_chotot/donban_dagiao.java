package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class donban_dagiao extends AppCompatActivity {
    TextView Btn_dangxuly , Btn_danggiao , Btn_choxacnhan ;
    ImageButton Btn_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donban_dagiao);
        Btn_dangxuly = (TextView) findViewById(R.id.tvdangxuly4);
        Btn_danggiao = (TextView)findViewById(R.id.tvdanggiao4);
        Btn_choxacnhan = (TextView)findViewById(R.id.tvchoxacnhan4);
        Btn_back = (ImageButton)findViewById(R.id.Btn_dagiaotohome);
        Btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(donban_dagiao.this, taikhoan.class);
                startActivity(back);
            }
        });
        Btn_danggiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent danggiao = new Intent(donban_dagiao.this, donban_danggiao.class);
                startActivity(danggiao);
            }
        });
        Btn_choxacnhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dagiao = new Intent(donban_dagiao.this, donban.class);
                startActivity(dagiao);
            }
        });
        Btn_dangxuly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dangxuly = new Intent(donban_dagiao.this, donban_dangxuly.class);
                startActivity(dangxuly);
            }
        });
    }
}
