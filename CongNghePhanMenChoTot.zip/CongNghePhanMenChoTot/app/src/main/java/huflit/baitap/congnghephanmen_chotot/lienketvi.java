package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class lienketvi extends AppCompatActivity {
    ImageButton Btn_lkv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lkvi);
        Btn_lkv = (ImageButton) findViewById(R.id.Btn_lienketvitohome);
        Btn_lkv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backtohome = new Intent(lienketvi.this, quanlytindang.class);
                startActivity(backtohome);
            }
        });
    }
}
