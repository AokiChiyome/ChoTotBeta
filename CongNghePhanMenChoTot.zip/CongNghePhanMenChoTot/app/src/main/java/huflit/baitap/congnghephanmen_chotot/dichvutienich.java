package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class dichvutienich extends AppCompatActivity {
    ImageButton Btn_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dichvutienich);
        Btn_back = (ImageButton) findViewById(R.id.Btn_Dichvutohome);
        Btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent quyvetrangchu = new Intent(dichvutienich.this, taikhoan.class);
                startActivity(quyvetrangchu);
            }
        });
    }
}
