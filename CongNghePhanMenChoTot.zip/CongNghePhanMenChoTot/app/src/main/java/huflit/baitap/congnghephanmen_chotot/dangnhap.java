package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class dangnhap extends AppCompatActivity {
    TextView Btn_toDangki ,Btn_Quenmatkhau;
    ImageButton Btn_backtohome;
    Button Btn_dangNhap;
    EditText emailedit,passedit;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        Btn_toDangki = (TextView)findViewById(R.id.tvdangky);
        Btn_backtohome = (ImageButton) findViewById(R.id.Btn_dangnhaptohome);
        Btn_Quenmatkhau = (TextView) findViewById(R.id.tvQuenMatKhau);
        Btn_dangNhap = (Button) findViewById(R.id.Btn_dangnhap);
        emailedit = findViewById(R.id.TenDangNhap);
        passedit = findViewById(R.id.MatKhau);
        Btn_Quenmatkhau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent quenmatkhau = new Intent(dangnhap.this, quenmatkhau.class);
                startActivity(quenmatkhau);
            }
        });
        Btn_backtohome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backtohome = new Intent(dangnhap.this, taikhoan.class);
                startActivity(backtohome);
            }
        });
        Btn_toDangki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent todangki = new Intent(dangnhap.this, dangki.class);
                startActivity(todangki);
            }
        });
        Btn_dangNhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                login();
            }
        });
    }
  private void login() {
        String email,pass;
        email = emailedit.getText().toString();
        pass = passedit.getText().toString();

        if(TextUtils.isEmpty(email)){
            Toast.makeText(this,"Vui lòng nhập Tên đăng nhập",Toast.LENGTH_SHORT).show();
            return;
        }

        if(TextUtils.isEmpty(pass)){
            Toast.makeText(this,"Vui lòng nhập mật khẩu",Toast.LENGTH_SHORT).show();
            return;
        }
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(getApplicationContext(),"Đăng nhập thành công",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(dangnhap.this,trangchu.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(getApplicationContext(),"Đăng nhập không thành công",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

}
