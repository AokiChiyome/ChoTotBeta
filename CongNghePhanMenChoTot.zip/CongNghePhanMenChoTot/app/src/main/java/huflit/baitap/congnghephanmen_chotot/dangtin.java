package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class dangtin extends AppCompatActivity {
    ImageButton Btn_Back  ;
    TextView Btn_dangtin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dangtindanhmucdangtin);
        Btn_Back = (ImageButton) findViewById(R.id.Btn_Dangtintohome);
        Btn_dangtin= (TextView) findViewById(R.id.Btn_dangnhap);
        Btn_dangtin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dangtindanhmuc = new Intent(dangtin.this, formdangtin.class);
                startActivity(Dangtindanhmuc);
            }
        });
        Btn_Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dangtindanhmuc = new Intent(dangtin.this, trangchu.class);
                startActivity(Dangtindanhmuc);
            }
        });

    }
}
