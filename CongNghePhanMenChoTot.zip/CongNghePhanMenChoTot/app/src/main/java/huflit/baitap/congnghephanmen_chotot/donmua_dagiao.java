package huflit.baitap.congnghephanmen_chotot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class donmua_dagiao extends AppCompatActivity {
    TextView Btn_dangxuly , Btn_danggiao , Btn_choxacnhan ;
    ImageButton Btn_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donmua_dagiao);
        Btn_dangxuly = (TextView) findViewById(R.id.tvdangxulydonmua4);
        Btn_danggiao = (TextView)findViewById(R.id.tvdanggiaodonmua4);
        Btn_choxacnhan = (TextView)findViewById(R.id.tvchoxacnhandonmua4);
        Btn_back = (ImageButton)findViewById(R.id.Btn_donmuagiaotohome);
        Btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(donmua_dagiao.this, taikhoan.class);
                startActivity(back);
            }
        });
        Btn_danggiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent danggiao = new Intent(donmua_dagiao.this, donmua_danggiao.class);
                startActivity(danggiao);
            }
        });
        Btn_choxacnhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dagiao = new Intent(donmua_dagiao.this, donmua.class);
                startActivity(dagiao);
            }
        });
        Btn_dangxuly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dangxuly = new Intent(donmua_dagiao.this, donmua_dangxuly.class);
                startActivity(dangxuly);
            }
        });
    }
}
